# Cause List — setup (about 20 minutes, one time)

## Part 1 — Put the app on GitHub Pages
1. Sign in (or sign up, free) at github.com.
2. Click **+ → New repository**. Name: `cause-list`. Choose **Public**. Click **Create repository**.
3. Click **uploading an existing file**. Drag in the 5 app files from this folder
   (index.html, sw.js, manifest.webmanifest, icon-192.png, icon-512.png). Click **Commit changes**.
4. Go to **Settings → Pages**. Under "Build and deployment" choose **Deploy from a branch**,
   branch **main**, folder **/ (root)**, then **Save**.
5. After 1–2 minutes your app is live at: `https://YOUR-USERNAME.github.io/cause-list/`
   (The repository holds only the app, never your cases or client names.)

## Part 2 — Create the Google sign-in ID (free)
1. Open console.cloud.google.com and sign in with the Google account whose Drive should hold the data.
2. Top bar → project picker → **New project** → name `Cause List` → **Create**.
3. Menu → **APIs & Services → Library** → search **Google Drive API** → **Enable**.
4. Menu → **APIs & Services → OAuth consent screen** (Google Auth Platform) → **Get started**:
   app name `Cause List`, your email as support/contact, Audience **External**, agree, **Create**.
5. **Data Access** (Scopes) → **Add or remove scopes** → tick `.../auth/drive.appdata` → **Update → Save**.
   (If you cannot find it, paste `https://www.googleapis.com/auth/drive.appdata` into "manually add scopes".)
6. **Audience** → **Publish app** → confirm. (This scope is non-sensitive, so no Google review is needed.
   If you prefer, leave it in Testing and add your own Gmail under **Test users**.)
7. **Clients → Create client** → type **Web application** → under **Authorized JavaScript origins** add
   `https://YOUR-USERNAME.github.io` (no path, no trailing slash) → **Create**.
8. Copy the **Client ID** (ends with `.apps.googleusercontent.com`).

## Part 3 — Give the app the Client ID
1. In your GitHub repository open `index.html` → pencil icon (Edit).
2. Find the line `const GOOGLE_CLIENT_ID="";` and paste the ID between the quotes. **Commit changes**.
   (Alternative: leave it empty; the app then shows a box to paste the ID on each device.)

## Part 4 — Use it
1. Open your app address on the laptop → tap **Sign in with Google & sync** → choose your account → Allow.
2. On the phone open the same address → sign in → browser menu → **Add to Home Screen** (installs like an app).
3. Move your old data once: in the old offline file press **Backup all data**; in the new app press
   **Restore / merge backup**, then **Sync now**.

Notes: tap **Save this day** for a day's list to sync. After about an hour the sign-in expires;
tap **Sync now** once to reconnect. Offline use always works; changes sync when you are online.
